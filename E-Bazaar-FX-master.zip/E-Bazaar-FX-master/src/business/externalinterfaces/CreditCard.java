
package business.externalinterfaces;


public interface CreditCard {
    String getNameOnCard();
    String getExpirationDate();
    String getCardNum();
    String getCardType();

}
