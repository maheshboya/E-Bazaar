package business.externalinterfaces;

public interface ProductFromGui {
	   
	 public String getMfgDate();
	 public String getProductName();
	 public String getQuantityAvail();
	 public String getUnitPrice();
	    
}
