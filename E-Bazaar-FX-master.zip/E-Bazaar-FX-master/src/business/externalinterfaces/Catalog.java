package business.externalinterfaces;

public interface Catalog {
	int getId();
	String getName();
	void setId(int id);
	void setName(String name);
}
