
package middleware.externalinterfaces;


public interface Cleanup {
    public void cleanup();

}
